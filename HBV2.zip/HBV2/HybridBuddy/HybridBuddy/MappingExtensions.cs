﻿namespace HybridBuddy
{
    public static class MappingExtensions
    {
        public static DTOs.CyclingStatsDto ToCyclingStatsDto(this DTOs.AthleteStatsDto athleteStats)
        {
            return new DTOs.CyclingStatsDto
            {
                BiggestRideDistance = athleteStats.biggest_ride_distance,
                AllRideTotal = athleteStats.all_ride_totals.count
            };
        }
    }
}
