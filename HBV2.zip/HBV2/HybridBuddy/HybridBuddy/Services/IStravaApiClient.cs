﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HybridBuddy.DTOs;

namespace HybridBuddy.Services
{
    public interface IStravaApiClient
    {
        Task<AthleteStatsDto> GetAthleteStats();
        Task<CyclingStatsDto> GetCyclingStats();
        public Task<AthleteDto> GetStravaAthleteInfo();
    }
}
