﻿using HybridBuddy.DTOs;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HybridBuddy.Services
{
    public class StravaApiClient : IStravaApiClient
    {
        private readonly HttpClient httpClient;
        private readonly string accessToken = "e46d5b405e6e078ef73bcc240c3b97074fd92c31";

        public StravaApiClient()
        {
            httpClient = new HttpClient();
        }

        public async Task<AthleteDto> GetStravaAthleteInfo()
        {
            try
            {
                string apiUrl = $"https://www.strava.com/api/v3/athlete";

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                HttpResponseMessage response = await httpClient.GetAsync(apiUrl);

                var athlete = JsonConvert.DeserializeObject<AthleteDto>(response.Content.ReadAsStringAsync().Result);

                return athlete;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task<AthleteStatsDto> GetAthleteStats()
        {
            try
            {
                string apiUrl = "https://www.strava.com/api/v3/athletes/62495999/stats";

                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                HttpResponseMessage response = await httpClient.GetAsync(apiUrl);

                var athleteStats = JsonConvert.DeserializeObject<AthleteStatsDto>(response.Content.ReadAsStringAsync().Result);

                return athleteStats;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }

        public async Task<CyclingStatsDto> GetCyclingStats()
        {
            try
            {
                var response = GetAthleteStats();

                var cyclingStats = MappingExtensions.ToCyclingStatsDto(response.Result);

                return cyclingStats;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return null;
            }
        }
    }
}
