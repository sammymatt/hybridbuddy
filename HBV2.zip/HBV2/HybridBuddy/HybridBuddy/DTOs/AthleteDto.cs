﻿namespace HybridBuddy.DTOs
{
    //    {
    //    "id": 62495999,
    //    "username": null,
    //    "resource_state": 2,
    //    "firstname": "Sam",
    //    "lastname": "Matthews",
    //    "bio": null,
    //    "city": "Essex, UK",
    //    "state": "",
    //    "country": null,
    //    "sex": "M",
    //    "premium": false,
    //    "summit": false,
    //    "created_at": "2020-06-28T10:18:48Z",
    //    "updated_at": "2023-11-13T15:36:38Z",
    //    "badge_type_id": 0,
    //    "weight": null,
    //    "profile_medium": "https://dgalywyr863hv.cloudfront.net/pictures/athletes/62495999/24731474/3/medium.jpg",
    //    "profile": "https://dgalywyr863hv.cloudfront.net/pictures/athletes/62495999/24731474/3/large.jpg",
    //    "friend": null,
    //    "follower": null
    //}
    public class AthleteDto
    {
        public int Id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string city { get; set; }
        public string country { get; set; }
    }
}