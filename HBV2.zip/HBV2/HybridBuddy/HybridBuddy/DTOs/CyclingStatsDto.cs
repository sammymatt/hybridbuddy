﻿namespace HybridBuddy.DTOs
{
    public class CyclingStatsDto
    {
        public int AllRideTotal { get; set; }
        public double BiggestRideDistance { get; set; }
    }
}