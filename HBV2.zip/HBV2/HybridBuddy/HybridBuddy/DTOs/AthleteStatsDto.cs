﻿namespace HybridBuddy.DTOs
{
    public class AthleteStatsDto
    {
        public double biggest_ride_distance { get; set; }
        public double? biggest_climb_elevation_gain { get; set; }

        public TotalsDto recent_ride_totals { get; set; }
        public TotalsDto all_ride_totals { get; set; }

        public TotalsDto recent_run_totals { get; set; }
        public TotalsDto all_run_totals { get; set; }

        public TotalsDto recent_swim_totals { get; set; }
        public TotalsDto all_swim_totals { get; set; }

        public TotalsDto ytd_ride_totals { get; set; }
        public TotalsDto ytd_run_totals { get; set; }
        public TotalsDto ytd_swim_totals { get; set; }
    }

    public class TotalsDto
    {
        public int count { get; set; }
        public double distance { get; set; }
        public int moving_time { get; set; }
        public int elapsed_time { get; set; }
        public double elevation_gain { get; set; }
        public int achievement_count { get; set; }
    }

}
