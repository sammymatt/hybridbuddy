﻿using HybridBuddy.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HybridBuddy.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StravaController : ControllerBase
    {
        private readonly ILogger<StravaController> _logger;
        private IStravaApiClient _stravaApiClient;


        public StravaController(ILogger <StravaController> logger, IStravaApiClient stravaApiClient)
        {
            _logger = logger;
            _stravaApiClient = stravaApiClient;
        }

        [HttpGet("GetAthleteInfo")]
        public async Task<IActionResult> GetAthleteInfo()
        {
            try
            {
                var result = await _stravaApiClient.GetStravaAthleteInfo();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("GetAthleteStats")]
        public async Task<IActionResult> GetAthleteStats()
        {
            try
            {
                var result = await _stravaApiClient.GetAthleteStats();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("GetCyclingStats")]
        public async Task<IActionResult> GetCyclingStats()
        {
            try
            {
                var result = await _stravaApiClient.GetCyclingStats();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
